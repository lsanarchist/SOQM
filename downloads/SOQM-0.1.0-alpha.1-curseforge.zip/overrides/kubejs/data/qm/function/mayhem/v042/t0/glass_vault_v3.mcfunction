# Questing Mayhem Expert0.4.2: authored bounded local event.
title @s actionbar {"text": "Прозорий натяк", "color": "light_purple"}
tellraw @s {"text": "Скарб видно. Тепер побачимо твоє терпіння.", "color": "gray"}
playsound minecraft:block.amethyst_block.chime player @s ~ ~ ~ 0.8 0.8
fill ~-4 ~ ~4 ~4 ~7 ~-4 minecraft:air replace
fill ~-3 ~-1 ~3 ~3 ~4 ~-3 minecraft:tinted_glass hollow
fill ~-3 ~-1 ~3 ~3 ~-1 ~-3 minecraft:mossy_stone_bricks replace
fill ~-3 ~ ~3 ~-3 ~4 ~3 minecraft:obsidian replace
fill ~3 ~ ~3 ~3 ~4 ~3 minecraft:obsidian replace
fill ~-3 ~ ~-3 ~-3 ~4 ~-3 minecraft:obsidian replace
fill ~3 ~ ~-3 ~3 ~4 ~-3 minecraft:obsidian replace
setblock ~ ~ ~ minecraft:chest[facing=west]{"LootTable":"qm:mayhem/t0/gear_cache"} replace
summon minecraft:spider ~1 ~ ~-1 {"Tags":["qm_lucky_event"],"PersistenceRequired":false,"CanPickUpLoot":false}
setblock ~-5 ~-1 ~ minecraft:cobblestone replace
fill ~-5 ~ ~ ~-5 ~2 ~ minecraft:air replace
tp @s ~-4.5 ~0.1 ~0.5
