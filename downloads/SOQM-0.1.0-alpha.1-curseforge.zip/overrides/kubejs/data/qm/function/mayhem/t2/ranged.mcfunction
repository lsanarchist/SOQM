# Questing Mayhem: authored for Minecraft 1.21.1.
title @s actionbar {"text": "Далекий постріл", "color": "gold", "bold": false}
playsound minecraft:block.amethyst_block.chime player @s ~ ~ ~ 0.7 1.0
loot give @s loot qm:mayhem/t2/ranged
